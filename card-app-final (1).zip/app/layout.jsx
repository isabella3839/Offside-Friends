import './globals.css'
export const metadata = {
  title: 'CardBoard',
  description: 'Give green, yellow, red cards to friends',
}
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
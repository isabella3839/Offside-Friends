'use client'
import React, { useState } from 'react'
import { motion } from 'framer-motion'

export default function Page() {
  const [users, setUsers] = useState([
    { id: 1, name: 'Lottie', green: 0, yellow: 0, red: 0 },
    { id: 2, name: 'Emily', green: 0, yellow: 0, red: 0 },
    { id: 3, name: 'Naomi', green: 0, yellow: 0, red: 0 },
    { id: 4, name: 'Tom', green: 0, yellow: 0, red: 0 },
    { id: 5, name: 'Lilly', green: 0, yellow: 0, red: 0 },
    { id: 6, name: 'Ella', green: 0, yellow: 0, red: 0 },
    { id: 7, name: 'Bella', green: 0, yellow: 0, red: 0 },
    { id: 8, name: 'Ben', green: 0, yellow: 0, red: 0 },
    { id: 9, name: 'Jack', green: 0, yellow: 0, red: 0 },
    { id: 10, name: 'Saffron', green: 0, yellow: 0, red: 0 },
    { id: 11, name: 'Libby', green: 0, yellow: 0, red: 0 },
    { id: 12, name: 'Kenny', green: 0, yellow: 0, red: 0 },
    { id: 13, name: 'Joanna', green: 0, yellow: 0, red: 0 },
  ])

  const [selectedUser, setSelectedUser] = useState(null)
  const [newUserName, setNewUserName] = useState('')
  const [sortByRed, setSortByRed] = useState(false)

  const giveCard = (userId, type) => {
    setUsers(prev => prev.map(u => (u.id === userId ? { ...u, [type]: u[type] + 1 } : u)))
    if (selectedUser?.id === userId) setSelectedUser(prev => ({ ...prev, [type]: prev[type] + 1 }))
  }

  const deleteCard = (userId, type) => {
    setUsers(prev => prev.map(u => (u.id === userId && u[type] > 0 ? { ...u, [type]: u[type] - 1 } : u)))
    if (selectedUser?.id === userId && selectedUser[type] > 0) setSelectedUser(prev => ({ ...prev, [type]: prev[type] - 1 }))
  }

  const addUser = () => {
    const name = newUserName.trim()
    if (!name) return
    const newUser = { id: Date.now(), name, green: 0, yellow: 0, red: 0 }
    setUsers(prev => [...prev, newUser])
    setNewUserName('')
  }

  const deleteUser = (userId) => {
    setUsers(prev => prev.filter(u => u.id !== userId))
    if (selectedUser?.id === userId) setSelectedUser(null)
  }

  const reorder = (list, startIndex, endIndex) => {
    const result = Array.from(list)
    const [removed] = result.splice(startIndex, 1)
    result.splice(endIndex, 0, removed)
    return result
  }

  const onDragStart = (e, index) => {
    e.dataTransfer.setData('text/plain', String(index))
    e.dataTransfer.effectAllowed = 'move'
  }

  const onDragOver = (e) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = 'move'
  }

  const onDrop = (e, dropIndex) => {
    e.preventDefault()
    const dragIndex = Number(e.dataTransfer.getData('text/plain'))
    if (Number.isNaN(dragIndex)) return
    const newOrder = reorder(users, dragIndex, dropIndex)
    setUsers(newOrder)
  }

  const displayedUsers = React.useMemo(() => {
    if (sortByRed) return [...users].sort((a, b) => b.red - a.red)
    return users
  }, [users, sortByRed])

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="container mx-auto">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">CardBoard ⚽</h1>
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={sortByRed} onChange={e => setSortByRed(e.target.checked)} />
              Sort by most red cards
            </label>
            <div className="text-sm text-gray-600">Shareable URL ready</div>
          </div>
        </header>

        <main className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <section>
            <h2 className="text-xl font-semibold mb-3">Friends</h2>

            <div className="flex gap-2 mb-4">
              <input
                value={newUserName}
                onChange={e => setNewUserName(e.target.value)}
                placeholder="New user name"
                className="border p-2 rounded w-full"
              />
              <button onClick={addUser} className="px-4 py-2 bg-blue-500 text-white rounded">Add</button>
            </div>

            <div className="grid gap-3">
              {displayedUsers.map((user, index) => (
                <div
                  key={user.id}
                  className="flex gap-3 items-center"
                  draggable={!sortByRed}
                  onDragStart={e => onDragStart(e, index)}
                  onDragOver={onDragOver}
                  onDrop={e => onDrop(e, index)}
                >
                  <button
                    onClick={() => setSelectedUser(user)}
                    className="w-full text-left p-3 bg-white rounded shadow hover:shadow-md flex justify-between items-center"
                  >
                    <div className="font-semibold">{user.name}</div>
                    <div className="flex gap-3">
                      <div>🟩 {user.green}</div>
                      <div>🟨 {user.yellow}</div>
                      <div>🟥 {user.red}</div>
                    </div>
                  </button>
                  <button onClick={() => deleteUser(user.id)} className="px-3 py-2 bg-red-200 rounded">🗑️</button>
                </div>
              ))}
            </div>
          </section>

          <section>
            {selectedUser ? (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 bg-white rounded shadow">
                <h2 className="text-2xl font-bold mb-4">{selectedUser.name}</h2>
                <div className="mb-4">
                  <div className="flex gap-2 mb-2">
                    <button onClick={() => giveCard(selectedUser.id, 'green')} className="px-3 py-2 rounded bg-green-100">🟩 Green</button>
                    <button onClick={() => giveCard(selectedUser.id, 'yellow')} className="px-3 py-2 rounded bg-yellow-100">🟨 Yellow</button>
                    <button onClick={() => giveCard(selectedUser.id, 'red')} className="px-3 py-2 rounded bg-red-100">🟥 Red</button>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => deleteCard(selectedUser.id, 'green')} className="px-3 py-2 rounded border">➖🟩 Remove</button>
                    <button onClick={() => deleteCard(selectedUser.id, 'yellow')} className="px-3 py-2 rounded border">➖🟨 Remove</button>
                    <button onClick={() => deleteCard(selectedUser.id, 'red')} className="px-3 py-2 rounded border">➖🟥 Remove</button>
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Current cards</h3>
                  <div className="flex gap-4 text-lg">
                    <div>🟩 {selectedUser.green}</div>
                    <div>🟨 {selectedUser.yellow}</div>
                    <div>🟥 {selectedUser.red}</div>
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="p-4 bg-white rounded shadow">Select a friend to give or remove cards</div>
            )}
          </section>
        </main>
      </div>
    </div>
  )
}
